Start from the obvious text file, then keep carving nested objects.
